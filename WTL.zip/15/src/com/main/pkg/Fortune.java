package com.main.pkg;

public interface Fortune {
	public int getDailyFortune();
}
