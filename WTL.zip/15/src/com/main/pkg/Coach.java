package com.main.pkg;

public interface Coach {
	public int getDailyWorkout();

}
